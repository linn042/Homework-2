package com.example.mobile_app_hw_2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    private val homeworkGrades = mutableListOf<Int>()
    private lateinit var editText: EditText
    private lateinit var addButton: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editText = findViewById(R.id.edit_text)
        addButton = findViewById(R.id.add_button)

        val part = findViewById<EditText>(R.id.participation_grade)
        val present = findViewById<EditText>(R.id.presentation_grade)
        val mid1 = findViewById<EditText>(R.id.midterm1_grade)
        val mid2 = findViewById<EditText>(R.id.midterm2_grade)
        val fin = findViewById<EditText>(R.id.finalproj_grade)

        val button = findViewById<Button>(R.id.myButton)
        val clear = findViewById<Button>(R.id.clearButton)

        val output = findViewById<TextView>(R.id.grade)

        var homeworkCounter = 0


        button.setOnClickListener {

            val participationGrade = part.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
            val presentationGrade =
                present.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
            val midterm1Grade = mid1.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
            val midterm2Grade = mid2.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
            val finalGrade = fin.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f


            val grade = editText.text.toString().toIntOrNull()
            var homeworkCounter = 0
        }

            addButton.setOnClickListener {
                val grade = editText.text.toString().toIntOrNull()
                if (grade == null) {
                    Toast.makeText(this, "Invalid input for homework grade. Please enter a number.", Toast.LENGTH_SHORT).show()
                } else if (grade < 0) {
                    Toast.makeText(this, "Invalid input for homework grade. Please enter a number between 0 and 100.", Toast.LENGTH_SHORT).show()
                } else if (homeworkGrades.size < 5) {
                    homeworkGrades.add(grade)
                    homeworkCounter++
                    editText.setText("")
                    addButton.isEnabled = homeworkCounter < 5
                    editText.isEnabled = addButton.isEnabled
                } else {
                    Toast.makeText(
                        this,
                        "Maximum number of homework grades reached.",
                        Toast.LENGTH_SHORT).show()
                }
                editText.setText("") // Add this line to clear the EditText box after receiving input
            }




            //Toast.makeText(this, output, Toast.LENGTH_SHORT).show()

            button.setOnClickListener {
                val participationGrade =
                    part.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
                val presentationGrade =
                    present.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
                val midterm1Grade = mid1.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
                val midterm2Grade = mid2.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f
                val finalGrade = fin.text.toString().toFloatOrNull()?.coerceIn(0f, 100f) ?: 0f

                if (homeworkGrades.size < 5) {
                    Toast.makeText(
                        this,
                        "Please enter at least 5 homework grades.",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@setOnClickListener
                }


                val homework_avg = if (homeworkGrades.isNotEmpty()) {
                    homeworkGrades.sum() / homeworkGrades.size
                } else {
                    100
                }

                val final =
                    homework_avg * 0.2f + participationGrade * 0.1 + presentationGrade * 0.1 + midterm1Grade * 0.1 + midterm2Grade * 0.2 + finalGrade * 0.3

                output.text = "Your grade for this semester is: ${String.format("%.2f", final)}"
            }
            //Toast.makeText(this, output, Toast.LENGTH_SHORT).show()


            clear.setOnClickListener {
                part.setText("")
                present.setText("")
                mid1.setText("")
                mid2.setText("")
                fin.setText("")
                output.text = ""
            }

    }
}